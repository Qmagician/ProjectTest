#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <QMenu>
#include <QAction>
#include <QSystemTrayIcon>
#include <QMap>
#include "chat.h"
class MyLrc;

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

protected:
    void closeEvent(QCloseEvent *); // 点击右上角关闭按钮，程序将在后台运行

private:
    void createContextMenu();    // 生成上下文菜单
    void createSystemTrayIcon(); // 生成系统托盘

    Ui::Widget *ui;
    chat *chatWindow;   // 声明一个聊天室的对象
    // 歌词处理部分
    MyLrc *lrc;
    QMap<qint64, QString> lrcMap;   // 声明一个存放歌曲时间和对应歌词的关联容器对象

   void resolverLrc(const QString &sourceFileName); // 歌词处理将歌曲的时间和对应的歌词存入关联容器中

    int volume;  // 歌曲播放音量
    // 动作部分
    QAction *restoreAction;  // 主面板动作
    QAction *quitAction;     // 退出
    QAction *seperatorAction1;  // 分割线
    QAction *seperatorAction2;
    QAction *seperatorAction3;

    QMenu *trayContextMenu;  // 托盘上下文菜单

    QMediaPlayer *player;   // 声明一个媒体对象
    QMediaPlaylist *playlist;  // 声明一个媒体播放列表对象
    QSystemTrayIcon *trayIcon;  // 声明一个系统托盘对象

private slots:
    void positionChanged(qint64);  // 播放进度
    void durationChanged(qint64);  //
    void playTo(int, int);  // 点击播放列表的某一首歌曲进行播放
    void updateSongList(int);   // 更新播放列表

    void importSongs();  // 加载歌曲
    void playPrevious(); // 上一曲
    void Play();  // 播放
    void Pause(); // 暂停
    void Stop();  // 停止
    void playNext();     // 下一曲

    void plusSound();     // 加音量
    void reduceSound();   // 减音量

    void setPlay_Loop();        // 列表循环
    void setPlay_Random();      // 随机播放
    void setPlay_CurrentLoop(); // 单曲循环
    void setPlay_Sequential();  // 顺序播放
    void playlist_Clear();     // 清空播放列表

    void setPosition(int);  // 随着拖动进度条更改播放进度
    void iconActivated(QSystemTrayIcon::ActivationReason reason); // 隐藏或显示

    void on_friendButton_clicked();  // 聊天室槽函数
    void on_lrcButton_clicked();
};

#endif // WIDGET_H
