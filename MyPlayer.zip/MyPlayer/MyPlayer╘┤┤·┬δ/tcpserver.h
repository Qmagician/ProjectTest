#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QDialog>

#include <QTime>
class QFile;
class QTcpServer;
class QTcpSocket;

namespace Ui {
class TcpServer;
}

class TcpServer : public QDialog
{
    Q_OBJECT

public:
    explicit TcpServer(QWidget *parent = 0);
    ~TcpServer();

    void initServer();   // 初始化发送端界面
    void refused();    // 拒绝接受

protected:
    void closeEvent(QCloseEvent *);  // 关闭事件

private:
    Ui::TcpServer *ui;

    qint16 tcpPort;  // 端口号
    QTcpServer *tcpServer;  // 声明一个服务端对象
    QString fileName;     // 存放文件名
    QString theFileName;  // 存放要发送的文件名
    QFile *localFile;   // 本地文件名

    qint64 TotalBytes;   // 存放总大小信息
    qint64 bytesWritten;  // 已发送数据大小
    qint64 bytesToWrite;   // 剩余数据大小
    qint64 payloadSize;   // 将整个大的文件分成很多的小部分进行发送
    QByteArray outBlock;

    QTcpSocket *clientConnection;

    QTime time;

private slots:
    void sendMessage(); // 文件发送
    void updateClientProgress(qint64 numBytes); // 更新进度条

    void on_serverOpenBtn_clicked();   // 选择要发送的文件

    void on_serverSendBtn_clicked();   // 发送

    void on_serverCloseBtn_clicked();  // 关闭（取消发送）

signals:
    void sendFileName(QString fileName);  // 文件发送信号
};

#endif // TCPSERVER_H
