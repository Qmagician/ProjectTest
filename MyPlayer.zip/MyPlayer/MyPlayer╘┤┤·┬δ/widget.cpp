#include "widget.h"
#include "ui_widget.h"
#include <QVideoWidget>
#include <QtWidgets>
#include <QDebug>
#include <QMediaMetaData>
#include <QTime>
#include <QTextStream>
#include "mylrc.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    setAttribute(Qt::WA_TranslucentBackground); // 隐藏背景
    // 将歌曲播放列表设置为不可编辑
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->horizontalSlider->setRange(0,0);  // 初始化播放进度范围
    volume = 60;  // 初始化音量为60

    createContextMenu();  // 调用生成上下文菜单函数
    createSystemTrayIcon();  // 调用生成系统托盘函数

    playlist = new QMediaPlaylist;  // 定义播放列表对象
    playlist->setPlaybackMode(QMediaPlaylist::Loop);  // 设置播放模式为列表循环模式

    player = new QMediaPlayer;  // 定义媒体对象
    player->setPlaylist(playlist);  // 为媒体对象加载播放列表
    player->setVolume(volume);  // 设置媒体播放音量
    lrc = new MyLrc(this);

    // 以下是一系列的信号槽函数的链接
    connect(ui->horizontalSlider, SIGNAL(sliderMoved(int)), this, SLOT(setPosition(int)));
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    connect(player, SIGNAL(durationChanged(qint64)), this, SLOT(durationChanged(qint64)));
    connect(playlist, SIGNAL(currentIndexChanged(int)), this, SLOT(updateSongList(int)));
    connect(ui->tableWidget, SIGNAL(cellClicked(int,int)), this, SLOT(playTo(int,int)));

    connect(ui->loadButton, SIGNAL(clicked()), this, SLOT(importSongs()));
    connect(ui->action_previous, SIGNAL(triggered()), this, SLOT(playPrevious()));
    connect(ui->action_next, SIGNAL(triggered()), this, SLOT(playNext()));
    connect(ui->action_pause, SIGNAL(triggered()), this, SLOT(Pause()));
    connect(ui->action_play, SIGNAL(triggered()), this, SLOT(Play()));

    connect(ui->action_Loop, SIGNAL(triggered()), this, SLOT(setPlay_Loop()));
    connect(ui->action_Random, SIGNAL(triggered()), this, SLOT(setPlay_Random()));
    connect(ui->action_CurrentLoop, SIGNAL(triggered()), this, SLOT(setPlay_CurrentLoop()));
    connect(ui->action_Sequen, SIGNAL(triggered()), this, SLOT(setPlay_Sequential()));
    connect(ui->action_clear, SIGNAL(triggered()), this, SLOT(playlist_Clear()));

    connect(ui->action_SoundPlus, SIGNAL(triggered()), this, SLOT(plusSound()));
    connect(ui->action_SoundReduce, SIGNAL(triggered()), this, SLOT(reduceSound()));
    connect(ui->action_Quit, SIGNAL(triggered()), qApp, SLOT(quit()));

    connect(ui->previousButton, SIGNAL(clicked()), this, SLOT(playPrevious()));
    connect(ui->nextButton, SIGNAL(clicked()), this, SLOT(playNext()));
    connect(ui->pauseButton, SIGNAL(clicked()), this,SLOT(Pause()));
    connect(ui->playButton, SIGNAL(clicked()), this, SLOT(Play()));
    connect(ui->stopButton, SIGNAL(clicked()), this, SLOT(Stop()));
    connect(ui->closeButton, SIGNAL(clicked()), this, SLOT(close()));
}

Widget::~Widget()
{
    delete ui;
}
// 由于媒体源播放时间的动态改变而执行的槽函数，及时更新进度条
void Widget::positionChanged(qint64 position)
{
    // 获取当前媒体源播放到的时间（以毫秒为单位，所以化成 分：秒 的形式）
    QTime currentTime(0,(player->position()/60000)%60,(player->position()/1000)%60);
    // ui->currentTimeLabel标签显示当前播放时间
    ui->currentTimeLabel->setText(currentTime.toString("mm:ss"));

    ui->horizontalSlider->setValue(position); // 设置进度天与播放时间一致

    //**************************以下是歌词标签显示歌词部分****************************
    if (!lrcMap.isEmpty())  // 当存放时间和对应歌词的关联容器不为空时
    {
        qint64 previous = 0;
        qint64 later = 0;
        foreach (qint64 value, lrcMap.keys())
        {
            if (player->position() >= value) // 如果查找到歌曲播放时间（位置）
            {
                previous = value;  // 则记录下在容器中找到的时间
            }
            else
            {
                later = value;
                break;
            }
        }
        if (later == 0)
            later = player->duration();
        QString currentLrc = lrcMap.value(previous); // 记录容器中当前时间的歌词
        if (currentLrc.length() < 1)   // 如果歌词为空,则歌词标签显示标题
            currentLrc = "酷仔音乐";
        // 如果新加载的歌词与原来的不同就显示新加载的，如果相同则不变
        if (currentLrc != lrc->text())
        {
            lrc->setText(currentLrc);
            qint64 intervalTime = later-previous;
            lrc->startLrcMask(intervalTime);
        }
        if (currentLrc != ui->lrcLabel->text())
        {
            // 利用html的功能将歌词设置为橙色，字号为 30
            ui->lrcLabel->setText(tr("<font color=#ff6600 size=30>%1<font>")
                                  .arg(currentLrc));          
        }
    }
    // 当该歌曲的歌词为空时则显示歌曲名称
    else ui->lrcLabel->setText("<<"+player->metaData("Title").toString()+">> 未能找到歌词");
}
// 更新总时间，当播放新歌曲时及时更新时间标签的显示和播放列表的相关信息
void Widget::durationChanged(qint64 duration)
{
    // 获取一首歌曲的总时间，转换为 分：秒 形式
    QTime totalTime(0,(player->duration()/60000)%60,(player->duration()/1000)%60);
    ui->totalTimeLabel->setText(totalTime.toString("mm:ss"));

    ui->horizontalSlider->setRange(0,duration);  // 及时更新进度条的范围

    // 由于媒体对象只能动态获取媒体源的信息，所以只有播放歌曲时才能更新列表中相应的信息
    QString s = player->metaData("Author").toString();  // 获取媒体源的艺术家信息
    int i = ui->tableWidget->currentRow();
    if (s!="" && ui->tableWidget->item(i,1)->text() == "播放读取...")
    {
        // 在列表中相应的单元显示媒体源的信息
        ui->tableWidget->setItem(i, 1,new QTableWidgetItem(s));
        ui->tableWidget->setItem(i, 2,new QTableWidgetItem(totalTime.toString("mm:ss")));
    }
    lrc->stopLrcMask();
    resolverLrc(ui->tableWidget->item(i, 3)->text());
}
// 点击播放列表中的某一首歌曲进行播放
void Widget::playTo(int i, int)
{
    playlist->setCurrentIndex(i);
    player->play();
}
// 当媒体对象加载的播放列表动态播放时，ui->songLabel标签中显示的歌曲名称也要实时更新
void Widget::updateSongList(int i)
{   
    ui->tableWidget->selectRow(i);
    ui->songLabel->setText(tr("<font color = red>正在播放：%1</font>")
                           .arg(ui->tableWidget->item(i, 0)->text()));
    // 把当前播放的歌曲（所在绝对路径）作为参数传递给歌词处理函数
    resolverLrc(ui->tableWidget->item(i,3)->text());
}
// 处理歌词文件
void Widget::resolverLrc(const QString &sourceFileName)
{
    lrcMap.clear();  // 先清空旧的歌词内容（如果有的话）
    if (sourceFileName.isEmpty())  // 判断传进来的文件路径是否为空，为空则返回
        return;

    QString fileName = sourceFileName;
    // 由于歌词文件与歌曲文件只是后缀名不一样，所以替换掉后缀名就能找到歌曲文件了
    //（当然歌曲和歌词文件要求放在同一个目录下）
    QString lrcFileName = fileName.remove(fileName.right(3)) + "lrc";
    QFile file(lrcFileName);
    if (!file.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        // 文件打开出错时给出相应的提示
        ui->lrcLabel->setText(tr("未找到歌词文件！"));
        return;
    }
    QTextStream in(&file);
    QString allText = in.readAll();  // 读取歌词文件中的内容并记录在allText中
    file.close();

    // 由于上面读取歌词文件时用的是QIODevice::Text，则把行结束符换成\n来读取
    // 此处则根据符号\n来进行分割，从而达到歌词分句存储的目的
    QStringList lines = allText.split("\n");


    // 使用正则表达式将时间标签和歌词内容分离，时间与歌词的形式是这样的
    // [00:20.13]就像星星落在地面 七彩闪烁世界
    QRegExp rx("\\[\\d{2}:\\d{2}\\.\\d{2}\\]");
    foreach (QString oneLine, lines)
    {
        // 清除歌词前面的时间，保留歌词文本
        QString temp = oneLine;
        temp.replace(rx, "");
        // 把时间标签和对应的歌词文本存放到lrcMap中
        int pos = rx.indexIn(oneLine, 0);
        while (pos != -1)
        {
            QString cap = rx.cap(0);
            // 将时间标签转换为时间数值，以毫秒为单位
            QRegExp regexp;
            regexp.setPattern("\\d{2}(?=:)");
            regexp.indexIn(cap);
            int minute = regexp.cap(0).toInt();
            regexp.setPattern("\\d{2}(?=\\.)");
            regexp.indexIn(cap);
            int second = regexp.cap(0).toInt();
            regexp.setPattern("\\d{2}(?=\\])");
            regexp.indexIn(cap);
            int millisecond = regexp.cap(0).toInt();
            qint64 totalTime = minute * 60000 + second * 1000 + millisecond * 10;
            // 插入到lrcMap中
            lrcMap.insert(totalTime, temp);
            pos += rx.matchedLength();
            pos = rx.indexIn(oneLine, pos);
        }
    }
    // 如果lrcMap为空
        if (lrcMap.isEmpty()) {
            ui->lrcLabel->setText(tr("歌词文件内容错误！"));
            return;
        }
}

// 从文件中导入歌曲到播放列表
void Widget::importSongs()
{
    // 打开文件选择对话框，并把媒体源（歌曲）的路径存放到列表中
    QString initialName = QDir::homePath();
    QStringList pathList = QFileDialog::getOpenFileNames(this, tr("选择文件"),
                           initialName, tr("mp3 (*.mp3);;All File(*.*)"));

    for (int i = 0; i < pathList.size(); i++)
    {
        // 把路径中的斜杠转换为和系统的一样（("c:/winnt/system32") returns "c:\winnt\system32"）
        QString path = QDir::toNativeSeparators(pathList.at(i));
        if (!path.isEmpty())
        {
            // 根据给出的路径把媒体源加载到播放列表中
            playlist->addMedia(QUrl::fromLocalFile(path));
            QString fileName = path.split("\\").last();  // 根据斜杠分割媒体源中的信息
            int rownum = ui->tableWidget->rowCount();    // 获得当前列表控件中的行数
            ui->tableWidget->insertRow(rownum);          // 在列表控件插入媒体源信息
            ui->tableWidget->setItem(rownum, 0,
                                     new QTableWidgetItem(fileName.split(".").front()));
            ui->tableWidget->setItem(rownum, 1,
                                     new QTableWidgetItem(tr("播放读取...")));
            ui->tableWidget->setItem(rownum, 2,
                                     new QTableWidgetItem(tr("播放读取...")));
            ui->tableWidget->setItem(rownum, 3,
                                     new QTableWidgetItem(path));
        }
        else return;
    }
}
// 上一曲
void Widget::playPrevious()
{
    int currentIndex = playlist->currentIndex();  // 获取当前播放歌曲的下标
    if (--currentIndex < 0)
        currentIndex = 0;    // 如果是列表的第一首（即没有再上一首），则当前下标赋值为第一首
    playlist->setCurrentIndex(currentIndex);
    player->play();  // 播放上一首歌曲（如果有的话）
    lrc->stopLrcMask();
}
// 播放
void Widget::Play()
{
    player->play();
    resolverLrc(ui->tableWidget->item(ui->tableWidget->currentRow(), 3)->text());
}
// 暂停
void Widget::Pause()
{
    player->pause();
    lrc->stopLrcMask();
}
// 停止（回到歌曲播放的起始位置）
void Widget::Stop()
{
    player->stop();
    lrc->stopLrcMask();
}
// 下一曲
void Widget::playNext()
{
    int currentIndex = playlist->currentIndex();  // 获取当前播放歌曲的下标
    if (++currentIndex == playlist->mediaCount())
        currentIndex = 0;   // 如果是列表的最后一首（即没有再下一首），则当前下标赋值为第一首
    playlist->setCurrentIndex(currentIndex);
    player->play(); // 播放下一首歌曲（如果有的话）
    lrc->stopLrcMask();
}
// 加大音量
void Widget::plusSound()
{
    volume += 20;  // 每次加大的音量为20
    if (volume >= 100)
    {
        volume = 100;  // 当达到100时，则动作变为不可用
        ui->action_SoundPlus->setEnabled(false);
    }
    player->setVolume(volume); // 重新设置音量为加大后的数值
    if (!ui->action_SoundReduce->isEnabled())
        ui->action_SoundReduce->setEnabled(true);  //  把减小音量动作设为可用
}
// 减小音量
void Widget::reduceSound()
{
    volume -= 20;  // 每次减小的音量为20
    if (volume <= 0)
    {
        volume = 0;   // 当达到0时，则动作变为不可用
        ui->action_SoundReduce->setEnabled(false);
    }
    player->setVolume(volume);  // 重新设置音量为减小后的数值
    if (!ui->action_SoundPlus->isEnabled())
        ui->action_SoundPlus->setEnabled(true);  //  把加大音量动作设为可用
}
// 设置播放模式为列表循环
void Widget::setPlay_Loop()
{
    playlist->setPlaybackMode(QMediaPlaylist::Loop);
}
// 设置播放模式为随机播放
void Widget::setPlay_Random()
{
    playlist->setPlaybackMode(QMediaPlaylist::Random);
}
// 设置播放模式为单曲循环
void Widget::setPlay_CurrentLoop()
{
    playlist->setPlaybackMode(QMediaPlaylist::CurrentItemInLoop);
}
// 设置播放模式为列表顺序
void Widget::setPlay_Sequential()
{
    playlist->setPlaybackMode(QMediaPlaylist::Sequential);
}
// 清空播放列表
void Widget::playlist_Clear()
{
    player->stop();
    playlist->clear();

    int i = 0, totalRow = ui->tableWidget->rowCount();
    for (i = totalRow-1; i >= 0; i--)
        ui->tableWidget->removeRow(i);

    ui->lrcLabel->setText(tr("<font color=#ff6600 size=30>酷仔音乐<font>"));
    ui->songLabel->clear();
}
// 当拖动进度条的时候，歌曲播放进度同步更新
void Widget::setPosition(int position)
{
    player->setPosition(position);
}
// 根据主页面是否正在显示，双击或单击显示主页面
void Widget::iconActivated(QSystemTrayIcon::ActivationReason reason)
{
    switch (reason)
    {
    case QSystemTrayIcon::DoubleClick:
    case QSystemTrayIcon::Trigger:
        if (this->isVisible() == true)
            ;
        else
        {
            // 显示主页面并设置为当前活动窗口
            this->show();
            this->activateWindow();
        }
        break;
    default:
        break;
    }
}
// 点击右上角的关闭按钮时，并未真正的退出程序，而是后台运行
void Widget::closeEvent(QCloseEvent *event)
{
    if (trayIcon->isVisible())
    {
        hide();
        trayIcon->showMessage(tr("提示"), tr("酷仔音乐将在后台运行"));
        event->ignore();  // 忽略关闭时间（后台运行）
    }
    else event->accept();
}
// 生成上下文菜单（右键菜单）
void Widget::createContextMenu()
{
    seperatorAction1 = new QAction(this);
    seperatorAction1->setSeparator(true);
    seperatorAction2 = new QAction(this);
    seperatorAction2->setSeparator(true);
    seperatorAction3 = new QAction(this);
    seperatorAction3->setSeparator(true);

    addAction(ui->action_previous);
    addAction(ui->action_next);
    addAction(ui->action_pause);
    addAction(ui->action_play);
    addAction(seperatorAction1);

    addAction(ui->action_Loop);
    addAction(ui->action_Random);
    addAction(ui->action_CurrentLoop);
    addAction(ui->action_Sequen);
    addAction(ui->action_clear);
    addAction(seperatorAction2);

    addAction(ui->action_SoundPlus);
    addAction(ui->action_SoundReduce);
    addAction(seperatorAction3);

    addAction(ui->action_Quit);

    // 按动作顺序显示菜单
    setContextMenuPolicy(Qt::ActionsContextMenu);
}
// 生成系统托盘
void Widget::createSystemTrayIcon()
{
    trayIcon = new QSystemTrayIcon(this);
    trayIcon->setIcon(QIcon(tr(":/images/listen_to_music.ico")));  // 设置系统托盘图标
    trayIcon->setToolTip(tr("酷仔音乐---音乐播放器"));  // 鼠标放置时的文字提醒

    // 以下是添加托盘右键菜单
    restoreAction = new QAction(tr("打开主面板"),this);
    connect(restoreAction, SIGNAL(triggered()), this, SLOT(show()));

    quitAction = new QAction(tr("退出"), this);
    connect(quitAction, SIGNAL(triggered()), qApp, SLOT(quit()));

    trayContextMenu = new QMenu(this);
    trayContextMenu->addAction(ui->action_previous);
    trayContextMenu->addAction(ui->action_next);
    trayContextMenu->addAction(ui->action_pause);
    trayContextMenu->addAction(ui->action_play);
    trayContextMenu->addSeparator();

    trayContextMenu->addAction(ui->action_Loop);
    trayContextMenu->addAction(ui->action_Random);
    trayContextMenu->addAction(ui->action_CurrentLoop);
    trayContextMenu->addAction(ui->action_Sequen);
    trayContextMenu->addAction(ui->action_clear);
    trayContextMenu->addSeparator();

    trayContextMenu->addAction(ui->action_SoundPlus);
    trayContextMenu->addAction(ui->action_SoundReduce);
    trayContextMenu->addSeparator();

    trayContextMenu->addAction(restoreAction);
    trayContextMenu->addAction(quitAction);
    trayIcon->setContextMenu(trayContextMenu);

    trayIcon->show();
    connect(trayIcon, SIGNAL(activated(QSystemTrayIcon::ActivationReason)),
            this,SLOT(iconActivated(QSystemTrayIcon::ActivationReason)));
}
// 打开聊天室，同时关闭主页面
void Widget::on_friendButton_clicked()
{
    close();
    chatWindow = new chat;
    chatWindow->show();
    connect(chatWindow, SIGNAL(mainWindowShow()), this, SLOT(show()));
}

void Widget::on_lrcButton_clicked()
{
    if (lrc->isHidden())
        lrc->show();
    else
        lrc->hide();
}
