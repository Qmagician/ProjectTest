#ifndef CHAT_H
#define CHAT_H

#include <QWidget>
class QUdpSocket;
class TcpServer;
#include <QTextCharFormat>
#include <QList>
#include <QTableWidget>

namespace Ui {
class chat;
}
// 定义枚举变量MessageType用来区分广播类型
enum MessageType{Message, NewParticipant, ParticipantLeft, FileName, Refuse};

class chat : public QWidget
{
    Q_OBJECT

public:
    explicit chat(QWidget *parent = 0);
    ~chat();

protected:
    // 有用户加入
    void newParticipant(QString userName,
                        QString localHostName, QString ipAddress);
    // 用户离开
    void participantLeft(QString userName,
                         QString localHostName, QString time);
    // 消息广播
    void sendMessage(MessageType type, QString serverAddress="");
    // 聊天表情
    void addEmotionItem(QString fileName);
    void initEmotion();

    QString getIP();   // 获取IP地址
    QString getUserName();  // 获取用户名
    QString getMessage();  //  获取消息内容

    // 用于接收端是否接收发送端发送过来的文件
    void hasPendingFile(QString userName, QString serverAddress,
                        QString clientAddress, QString fileName);
    // 保存接收过来的文件
    bool saveFile(const QString& fileName);
    // 窗口关闭事件
    void closeEvent(QCloseEvent *);

private:
    Ui::chat *ui;

    QList<QString> list;   // 声明一个存放表情图像路径的列表
    int row = 0, column = 0;
    QUdpSocket *udpSocket;   // 声明一个udp套接字对象
    qint16 port;   // 声明一个端口号变量

    QString fileName;  // 用于传输文件时保存文件的名字
    TcpServer *server;  // 声明一个TCP服务对象
    QColor color;

signals:
    void mainWindowShow();   // 主页面显示信号
private slots:
    void processPendingDatagrams(); // 用于接收UDP广播发送过来的数据

    void on_sendButton_clicked();  // 消息发送按钮槽函数

    void getFileName(QString);  // 获取传输文件的名字
    void on_sendToolButton_clicked();    // 发送文件
    void on_fontComboBox_activated(const QString &arg1);  // 设置字体类型
    void on_sizeComboBox_activated(const QString &arg1);  // 设置字体大小
    void on_boldToolButton_clicked(bool checked);    // 粗体
    void on_italicToolButton_clicked(bool checked);  // 斜体
    void on_underlineToolButton_clicked(bool checked);  // 下划线
    void on_colorToolButton_clicked();    // 设置字体颜色

    void currentFormatChanged(const QTextCharFormat &format);  // 字体格式变换
    void on_saveToolButton_clicked();    // 保存聊天记录
    void on_clearToolButton_clicked();   // 清除聊天记录
    void on_exitButton_clicked();  // 退出
    void on_emojiButton_clicked(); // 表情
    void on_emojiTableWidget_clicked(const QModelIndex &index); // 表情选择
};

#endif // CHAT_H
