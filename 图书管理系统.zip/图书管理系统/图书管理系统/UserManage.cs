﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 图书管理系统
{
    public partial class UserManage : Form
    {
        public UserManage()
        {
            InitializeComponent();
        }

        // 数据库连接
        SqlConnection connection = new SqlConnection(
               @"Data Source=(LocalDB)\MSSQLLocalDB;
                AttachDbFilename=E:\PROGRAMES\C#\图书管理系统\图书管理系统\library.mdf;
                Integrated Security=True;Connect Timeout=30");

        SqlDataAdapter adapter = new SqlDataAdapter();

        public void showData()
        {         
            SqlCommand select = new SqlCommand("select * from ReaderInfor", connection); 
            adapter.SelectCommand = select;
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
        // 当点击右上角关闭按钮时，显示主界面
        private void UserManage_FormClosing(object sender, FormClosingEventArgs e)
        {
            LibraryManage libraryMan = new LibraryManage();
            libraryMan.Show();
        }
        // 点击 “返回”按钮
        private void toLibraryManage_Click(object sender, EventArgs e)
        {
            this.Close(); //事件机制会执行UserManage_FormClosing事件
        }
        // 显示行号
        private void dataGridView1_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            //显示在HeaderCell上
            for (int i = 0; i < this.dataGridView1.Rows.Count; i++)
            {
                DataGridViewRow r = this.dataGridView1.Rows[i];
                r.HeaderCell.Value = string.Format("{0}", i + 1);
            }
            this.dataGridView1.Refresh();
        }
        // 按字段进行查询
        private void findBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(findKeyBox.Text) || string.IsNullOrEmpty(findValueText.Text))
            {
                MessageBox.Show("请先选择查找字段或填写查找关键字", "提示", 
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                return;
            }
            int findKeyIndex = findKeyBox.SelectedIndex;
            string findValue = findValueText.Text;
            
            SqlCommand select = new SqlCommand();
            select.Connection = connection;
            DataSet ds = new DataSet();
            switch (findKeyIndex)
            {
                case 0:
                    select.CommandText = "select * from ReaderInfor where account=" + findValue;
                    break;
                case 1:
                    select.CommandText = "select * from ReaderInfor where name=\'" + findValue+"\'";
                    break;
                case 2:
                    select.CommandText = "select * from ReaderInfor where class=" + findValue;
                    break;
                default:break;
            }
            
            adapter.SelectCommand = select;
            adapter.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("抱歉！您所查找的数据不在数据库中！", "提示",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            }
        }

        private void freshBtn_Click(object sender, EventArgs e)
        {
            findKeyBox.Text = null;
            findValueText.Text = null;
            showData();
        }
    }
}
