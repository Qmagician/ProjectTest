﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 图书管理系统
{
    public class DataBase
    {
        public SqlConnection connection = new SqlConnection(
               @"Data Source=(LocalDB)\MSSQLLocalDB;
                AttachDbFilename=E:\PROGRAMES\C#\图书管理系统\图书管理系统\library.mdf;
                Integrated Security=True;Connect Timeout=30");
        public SqlCommand select = new SqlCommand();
        public SqlDataAdapter adapter = new SqlDataAdapter();
    }
}
